pes = {
    "meilleur puissance": "Adriano",
    "astuce": "tir milieu terrain",
    "marque": "Konami"
}

pes['meilleur puissance']

pes['marque']
