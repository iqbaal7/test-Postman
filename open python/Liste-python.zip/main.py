voitures = ["Porsche", "BMW", "Mercedes", "Audi"]
voitures[3]

voitures.append("Ferrari")
print(voitures)

voitures.remove("Ferrari")
print(voitures)

len(voitures)

voitures.sort()
print(voitures)
