# boucle for
exo_couleur = ["rouge", "jaune", "bleu", "violet"]
for couleurs in exo_couleur:
print(couleurs)

# boucle while
capacite_maximale = 10
capacite_actuelle = 3
while capacite_actuelle < capacite_maximale: capacite_actuelle += 1
  
print("capacité actuelle :", capacite_actuelle)