prenom = "Kylian"
nom = "Mbappe"
age = 25
coupe = "coupe du monde"

print(
    f"Je m'appelle {prenom} {nom} j'ai gagné une {coupe} à l'age de {age} ans."
)
