# fonction sans parametre
def notification():
  print("Vous avez un nouveau message !")


notification()


# fonction avec parametre
def combattant(nom, prenom):
  print("Nom du combattant :", nom)
  print("Prenom du combattant:", prenom)


combattant("Brock", "Lesnar")
